//
//  AppConfig.swift
//  OBWApp
//
//  Created by Yon Lau on 2019/6/24.
//  Copyright © 2019 YonLau. All rights reserved.
//

struct AppConfig {
    static var internalDebug = false
}


