var bleApi = require('baseBleApi.js');



module.exports = {
  sendCommand: sendCommand
}


function sendCommand(params) {

  var defaults = {
    adviceId: "",
    sendCommend: "",
    onSuccessCallBack: function successCallBack(res) { },
    onFailCallBack: function failCallBack(res) { },
    onCompleteCallBack: function completeCallBack(res) { },
    services: ["0000AAAA-0000-1000-8000-00805F9B34FB"],
    writeServiceUUID: "",
    notifyServiceUUID: "",
    notifyCharacteristicUUID: "0000BBB1-0000-1000-8000-00805F9B34FB",
    writeCharacteristicUUID: "0000BBB0-0000-1000-8000-00805F9B34FB"
  }
  var setParams = Object.assign(defaults, params)
  bleApi.writeCommend(setParams);

}

/*
此接口中service可以不写，但是adviceId,链接时必须写，，链接标志，writeServiceUUID，notifyServiceUUID，notifyCharacteristicUUID，writeCharacteristicUUID
这几个参数是为了进行ble设备通信所用到的
*/ 