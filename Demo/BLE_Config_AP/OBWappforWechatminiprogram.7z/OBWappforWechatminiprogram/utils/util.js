const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

var _this = null

function initBle(that) {
  _this = that
/*  try {
    // 同步获取系统信息 反之有异步 自己根据情况使用
    const res = wx.getSystemInfoSync()
    var tempPlatform = res.platform
    var tempVersion = res.version
    var tempSystem = res.system
    //判断用户当前的微信版本是否支持ble
    _checkPermission(tempPlatform, tempVersion, tempSystem)
  } catch (e) {
    // Do something when catch error
  }
*/  
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join('');
}

// 字符串转byte
function stringToBytes(str) {
  var strArray = new Uint8Array(str.length);
  for (var i = 0; i < str.length; i++) {
    strArray[i] = str.charCodeAt(i);
  }
  const array = new Uint8Array(strArray.length)
  strArray.forEach((item, index) => array[index] = item)
  return array.buffer;
}

function d2h(d) {
  return d.toString(16);
}
function h2d(h) {
  return parseInt(h, 16);
}
function stringToHex(tmp) {
  var str = '',
    i = 0,
    tmp_len = tmp.length,
    c;

  for (; i < tmp_len; i += 1) {
    c = tmp.charCodeAt(i);
    str += d2h(c) + '';
  }
  return str;
}
/*
function hexToString(tmp) {
  var arr = tmp.split(' '),
    str = '',
    i = 0,
    arr_len = arr.length,
    c;

  for (; i < arr_len; i += 1) {
    c = String.fromCharCode(h2d(arr[i]));
    str += c;
  }

  return str;
}
*/


//16进制转字符串
function hexToString(str) {
  var trimedStr = str.trim();
  var rawStr =
    trimedStr.substr(0, 2).toLowerCase() === "0x" ?
      trimedStr.substr(2) :
      trimedStr;
  var len = rawStr.length;
  if (len % 2 !== 0) {
    // alert("Illegal Format ASCII Code!");
    return "";
  }
  var curCharCode;
  var resultStr = [];
  for (var i = 0; i < len; i = i + 2) {
    curCharCode = parseInt(rawStr.substr(i, 2), 16); // ASCII Code Value
    resultStr.push(String.fromCharCode(curCharCode));
  }
  return resultStr.join("");
}

/*微信app版本比较*/
function versionCompare(ver1, ver2) {
  var version1pre = parseFloat(ver1)
  var version2pre = parseFloat(ver2)
  var version1next = parseInt(ver1.replace(version1pre + ".", ""))
  var version2next = parseInt(ver2.replace(version2pre + ".", ""))
  if (version1pre > version2pre)
    return true
  else if (version1pre < version2pre)
    return false
  else {
    if (version1next > version2next)
      return true
    else
      return false
  }
}


//分包方法
function datasubpck(datahex) {
  var arrayObj = new Array();
  for (var i = 0; i < datahex.length; i += 40) {
    // 预加 最大包长度，如果依然小于总数据长度，可以取最大包数据大小
    if ((i + 40) < datahex.length) {
      arrayObj.push(datahex.substring(i, i + 40))

    } else {
      arrayObj.push(datahex.substring(i))
    }
  }
  return arrayObj;
}


var totalLength = 0
function deviceWrite(connectedDeviceId, dataArray, index1) {

  console.log('++++++++++++++++++')
  totalLength = dataArray.length
  console.log("index:::" + index1)
  var subhex = ''
  subhex = dataArray[index1]

  var temp = subhex;//'0600031567890302'
  var prefix = '0x'
  var affix = ','
  var temp2 = ''
  for (var i = 0; i < temp.length / 2; i++) {
    if (i < (temp.length / 2 - 1)) {
      temp2 = temp2 + prefix + temp.substring(i * 2, i * 2 + 2) + affix
    }
    else {
      temp2 = temp2 + prefix + temp.substring(i * 2)
    }
    console.log("i:" + i + "temp2:" + temp2)
  }


  //subhex = subhex.toLowerCase()
  console.log('pppppppp---' + subhex)
  var buffer1 = new ArrayBuffer(subhex.length / 2)//字节长度 一个字节两个字符所以除以2
  var dataView1 = new DataView(buffer1)
  console.log('++++++++++++++++++3')
  var str1 = temp2;
  console.log('aaaaaa' + str1)
  var arr1 = str1.split(',')
  var val;
  for (var i = 0; i < arr1.length; i++) {
    val = parseInt(arr1[i], 16)
    dataView1.setInt8(i, val);
  }
  console.log('++++++++++++++++++4')

  console.log("bbbsubhex:::" + subhex)
  index1 = index1 + 1
  var typedArray = new Uint8Array(subhex.match(/[\da-f]{2}/gi).map(function (h) {
    return parseInt(h, 16)
  }))
  console.log(typedArray)
  console.log("发送的指令===" + ab2hex(buffer1))
  console.log("发送指令函数deviceId：" + connectedDeviceId)
  console.log("发送指令函数serviceId：" + "0000AAAA-0000-1000-8000-00805F9B34FB")
  console.log("发送指令函数CharacteristicsId：" + "0000BBB0-0000-1000-8000-00805F9B34FB")

  wx.writeBLECharacteristicValue({
    // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取  
    deviceId: connectedDeviceId,
    // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取  
    serviceId: "0000AAAA-0000-1000-8000-00805F9B34FB",//writeServicweId,
    // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取  
    characteristicId: "0000BBB0-0000-1000-8000-00805F9B34FB",//writeCharacteristicsId,
    value: buffer1,
    success: function (res) {
      //sleep(200)
      console.log('writeBLECharacteristicValue success', res.errMsg)
      setTimeout(function () {

        if (index1 < totalLength) {
          deviceWrite(connectedDeviceId, dataArray, index1);

        } else {
          console.log("stop command" + index1)
        }

      }, 40)


    },
    fail: function (res) {
      console.log("写入失败");

    }
  })

}




/****
 * 接收设备返回
 */

function onBLECharacteristicValueChange() {
  var receData = "";
  wx.onBLECharacteristicValueChange(function (res) {

    let dataResult = []
    console.log("接收数据长度:" + res.value.byteLength);
    console.log("jieshoudao:" + ab2hex(res.value));
    receData = receData + ab2hex(res.value);

    console.log('onBLECharacteristicValueChange' + JSON.stringify(res));
    let buffer = res.value
    let dataView = new DataView(buffer)
    
    console.log("拿到的数据")
    console.log("dataView.byteLength", dataView.byteLength)
    for (let i = 0; i < dataView.byteLength; i++) {
      console.log("0x" + dataView.getUint8(i).toString(16))
      dataResult.push(dataView.getUint8(i).toString(16))
    }

    

    _this.notifyListener(dataResult, (ab2hex(res.value)), res.value.byteLength ,res);

    
    
  })
  
  



}

function passdata(rcvData){

  wx.setStorage({
    key: 'orderInfo',
    data: rcvData,
    success: function (res) {
      wx.navigateTo({
        url: '../wifi/wifi'
      })

    }
  })

}

module.exports = {
  formatTime: formatTime,
  stringToBytes: stringToBytes,
  hexToString: hexToString,
  versionCompare: versionCompare,
  ab2hex: ab2hex,
  onBLECharacteristicValueChange: onBLECharacteristicValueChange,
  deviceWrite: deviceWrite,
  datasubpck: datasubpck,
  initBle: initBle,
  stringToHex: stringToHex
}

