var app = getApp();
var utils = require("../../utils/util.js");

//消息提示框
function showLoading(msg) {
  wx.showLoading({
    title: msg,
  })
}


function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i;
    }
  }
  return -1;

}


/*
// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }

  )
  return hexArr.join('');
}
*/


Page({

  data: {

    devices: [],
    connected: false,
    chs: [],
    connectedDeviceId: "", //已连接设备uuid
    services: "", // 连接设备的服务
    characteristics: "",   // 连接设备的状态值
    writeServicweId: "", // 可写服务uuid
    writeCharacteristicsId: "",//可写特征值uuid
    readServicweId: "", // 可读服务uuid
    readCharacteristicsId: "",//可读特征值uuid
    notifyServicweId: "", //通知服务UUid
    notifyCharacteristicsId: "", //通知特征值UUID
    ALLUUID: "0000AAAA-0000-1000-8000-00805F9B34FB", //同时具有可读、可写、通知三种属性的UUID
    scroll_height: 0,

    

  },

  openBluetoothAdapter() {
    

    wx.openBluetoothAdapter({
      success: (res) => {
        console.log('openBluetoothAdapter success', res)
        this.startBluetoothDevicesDiscovery()
      },

      fail: (res) => {

        console.log('error', res)

        if (res.errCode === 10001) {

          wx.onBluetoothAdapterStateChange(function (res) {

            console.log('onBluetoothAdapterStateChange', res)

            if (res.available) {

              this.startBluetoothDevicesDiscovery()

            }

          })

        }

      }

    })

  },

  getBluetoothAdapterState() {

    wx.getBluetoothAdapterState({

      success: (res) => {

        console.log('getBluetoothAdapterState', res)

        if (res.discovering) {

          this.onBluetoothDeviceFound()

        } else if (res.available) {

          this.startBluetoothDevicesDiscovery()

        }

      }

    })

  },

  startBluetoothDevicesDiscovery() {

 
    

    if (this._discoveryStarted) {

      return

    }

    this._discoveryStarted = true

    wx.startBluetoothDevicesDiscovery({

      allowDuplicatesKey: true,

      success: (res) => {

        console.log('lanya', res)

        this.onBluetoothDeviceFound()

      },

    })

  },

  stopBluetoothDevicesDiscovery() {
    wx.stopBluetoothDevicesDiscovery()
  },

  onBluetoothDeviceFound() {

    wx.onBluetoothDeviceFound((res) => {

      res.devices.forEach(device => {

        if (!device.name && !device.localName) {

          return

        }
        const foundDevices = this.data.devices

        const idx = inArray(foundDevices, 'deviceId', device.deviceId)

        const data = {}

        if (idx === -1) {

          data[`devices[${foundDevices.length}]`] = device

        } else {

          data[`devices[${idx}]`] = device

        }

        this.setData(data)

      })

    })

  },


  //连接设备
  connectTO: function (e) {
    showLoading('连接中...')
    var that = this;
    const ds = e.currentTarget.dataset
    const device = ds
    const deviceId = ds.deviceId
    const name = ds.name
    wx.createBLEConnection({
      deviceId: deviceId,
      success: function (res) {
        console.log(res.errMsg);
        that.setData({
          connectedDeviceId: deviceId,
          msg: "已连接" + deviceId,
          msg1: "",
          devicesFlag: false

        })
        showLoading('连接成功')
        setTimeout(function () {
          wx.hideLoading()
        }, 2000)

        //5、停止搜索设备
        that.stopBluetoothDevicesDiscovery()
        //6、 获取连接设备的service服务
        wx.getBLEDeviceServices({
          // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
          deviceId: that.data.connectedDeviceId,
          success: function (res) {
            console.log('device services:', JSON.stringify(res.services));
            that.setData({
              services: res.services,
              msg: JSON.stringify(res.services),
            })

            //7、获取连接设备的所有特征值  for循环获取不到值 start
            wx.getBLEDeviceCharacteristics({
              // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
              deviceId: that.data.connectedDeviceId,
              // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
              serviceId: that.data.ALLUUID,
              success: function (res) {
                for (var i = 0; i < res.characteristics.length; i++) {


                  if (res.characteristics[i].properties.notify) {
                    console.log("获取开启notify的ServicweId：", that.data.ALLUUID);
                    console.log("获取开启notify的CharacteristicsId：", res.characteristics[i].uuid);
                    that.setData({
                      notifyServicweId: that.data.ALLUUID,
                      notifyCharacteristicsId: res.characteristics[i].uuid,

                    })
                  }
                  if (res.characteristics[i].properties.write) {
                    console.log("获取开启write的ServicweId：", that.data.ALLUUID);
                    console.log("获取开启write的CharacteristicsId：", res.characteristics[i].uuid);
                    that.setData({
                      writeServicweId: that.data.ALLUUID,
                      writeCharacteristicsId: res.characteristics[i].uuid,
                    })

                  } else if (res.characteristics[i].properties.read) {
                    console.log("读取函数：", that.data.ALLUUID);
                    console.log("读取函数：", res.characteristics[i].uuid);
                    that.setData({
                      readServicweId: that.data.ALLUUID,
                      readCharacteristicsId: res.characteristics[i].uuid,
                    })

                  }

                }
                //console.log('device getBLEDeviceCharacteristics:', res.characteristics);

                that.setData({
                  msg: JSON.stringify(res.characteristics),
                })

                ////8、启用低功耗蓝牙设备特征值变化时的 notify 功能
                var notifyServicweId = that.data.notifyServicweId.toUpperCase();
                var notifyCharacteristicsId = that.data.notifyCharacteristicsId.toUpperCase();
                console.log("启用notify的serviceId", notifyServicweId);
                console.log("启用notify的notifyCharacteristicsId", notifyCharacteristicsId);

                wx.notifyBLECharacteristicValueChange({
                  state: true, // 启用 notify 功能
                  type: 'notification',
                  // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
                  deviceId: that.data.connectedDeviceId,
                  // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
                  serviceId: "0000AAAA-0000-1000-8000-00805F9B34FB",//that.data.notifyServicweId,

                  // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
                  characteristicId: "0000BBB1-0000-1000-8000-00805F9B34FB",//that.data.notifyCharacteristicsId,

                  success: function (res) {
                    console.log('66666启用通知notifyBLECharacteristicValueChange success', res.errMsg)

                    setTimeout(function () {
                      //9、接收函数
                      utils.onBLECharacteristicValueChange()
                    }, 500)


                  },
                  fail: function () {
                    console.log('shibai0');
                    console.log(that.data.notifyServicweId);
                    console.log(that.data.notifyCharacteristicsId);
                  },
                })



              },
              fail: function () {
                console.log("fail");
              },
              complete: function () {
                console.log("complete");
                wx.navigateTo({
                  url: '/pages/function/function?name=' + encodeURIComponent(device.name) + '&deviceId=' + encodeURIComponent(deviceId)
                });
              }
            })
            //7、获取连接设备的所有特征值  for循环获取不到值 end

          }



        })

      },
      fail: function () {
        console.log("调用失败");
      },
      complete: function () {
        console.log("调用结束");
      }

    })
    console.log(that.data.connectedDeviceId);
  },
  /*
    createBLEConnection(e) {
      const ds = e.currentTarget.dataset
      const deviceId = ds.deviceId
      const name = ds.name
      wx.createBLEConnection({
        deviceId,
        success: (res) => {
          this.setData({
            connected: true,
            name,
            deviceId,
          })
          this.getBLEDeviceServices(deviceId)
        }
      })
      this.stopBluetoothDevicesDiscovery()
    },
  */

  closeBLEConnection() {
    wx.closeBLEConnection({
      deviceId: this.data.deviceId
    })

    this.setData({
      connected: false,
      chs: [],
      canWrite: false,
    })

  },

  getBLEDeviceServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId,
      success: (res) => {
        for (let i = 0; i < res.services.length; i++) {
          if (res.services[i].isPrimary) {
            this.getBLEDeviceCharacteristics(deviceId, res.services[i].uuid)
            return
          }

        }

      }

    })

  },

  getBLEDeviceCharacteristics(deviceId, serviceId) {

    wx.getBLEDeviceCharacteristics({
      deviceId,
      serviceId,
      success: (res) => {
        console.log('getBLEDeviceCharacteristics success', res.characteristics)
        for (let i = 0; i < res.characteristics.length; i++) {
          let item = res.characteristics[i]
          if (item.properties.read) {
            wx.readBLECharacteristicValue({
              deviceId,
              serviceId,
              characteristicId: item.uuid,
            })

          }

          if (item.properties.write) {
            this.setData({
              canWrite: true
            })
            this._deviceId = deviceId
            this._serviceId = serviceId
            this._characteristicId = item.uuid
            this.writeBLECharacteristicValue()
          }

          if (item.properties.notify || item.properties.indicate) {
            wx.notifyBLECharacteristicValueChange({
              deviceId,
              serviceId,
              characteristicId: item.uuid,
              state: true,
            })

          }

        }

      },

      fail(res) {
        console.error('getBLEDeviceCharacteristics', res)
      }

    })

    // 操作之前先监听，保证第一时间获取数据

    wx.onBLECharacteristicValueChange((characteristic) => {

      const idx = inArray(this.data.chs, 'uuid', characteristic.characteristicId)

      const data = {}

      if (idx === -1) {

        data[`chs[${this.data.chs.length}]`] = {

          uuid: characteristic.characteristicId,

          value: utils.ab2hex(characteristic.value)

        }

      } else {

        data[`chs[${idx}]`] = {

          uuid: characteristic.characteristicId,

          value: utils.ab2hex(characteristic.value)

        }

      }

      // data[`chs[${this.data.chs.length}]`] = {

      //   uuid: characteristic.characteristicId,

      //   value: utils.ab2hex(characteristic.value)

      // }

      this.setData(data)

    })

  },

  writeBLECharacteristicValue() {

    // 向蓝牙设备发送一个0x00的16进制数据

    let buffer = new ArrayBuffer(1)

    let dataView = new DataView(buffer)
    dataView.setUint8(0, Math.random() * 255 | 0)
    wx.writeBLECharacteristicValue({
      deviceId: this._deviceId,
      serviceId: this._deviceId,
      characteristicId: this._characteristicId,
      value: buffer,

    })

  },

  closeBluetoothAdapter() {
    wx.closeBluetoothAdapter()
    this._discoveryStarted = false

  },

  onLoad: function (options) {
    let windowHeight = wx.getSystemInfoSync().windowHeight // 屏幕的高度    
    let windowWidth = wx.getSystemInfoSync().windowWidth // 屏幕的宽度    
    this.setData({      
      scroll_height: windowHeight * 500 / windowWidth - (0) - 30 
      })  
  },


})
