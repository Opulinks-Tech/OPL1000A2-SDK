// pages/function/function.js
var app = getApp();
var utils = require("../../utils/util.js");


function sleep(numberMillis) {
  console.log("睡眠" + numberMillis + "毫秒")
  var now = new Date();
  var exitTime = now.getTime() + numberMillis;
  while (true) {
    now = new Date();
    if (now.getTime() > exitTime)
      return;
  }
}


var receData = '';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    textLog: "",
    connectedDeviceId: "",
    name: "",
    allRes: "",
    serviceId: "0000AAAA-0000-1000-8000-00805F9B34FB",
    res: "",
    readCharacteristicId: "",
    writeCharacteristicId: "0000BBB0-0000-1000-8000-00805F9B34FB",
    notifyCharacteristicId: "0000BBB1-0000-1000-8000-00805F9B34FB",
    connected: true

  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    utils.initBle(that)
    let devid = decodeURIComponent(options.deviceId);
    let devname = decodeURIComponent(options.name);
    let log = that.data.textLog + "设备名=" + devname + "\n设备UUID=" + devid + "\n";
    this.setData({
      textLog: log,
      deviceId: devid,
      name: devname,
    });
    wx.getStorage({
      key: 'orderInfo',
      success: function (res) {
        that.setData({
          jieshoudao: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (wx.setKeepScreenOn) {
      wx.setKeepScreenOn({
        keepScreenOn: true,
        success: function (res) {
          //console.log('保持屏幕常亮')
        }
      })
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //断开与低功耗蓝牙设备的连接
  bleDisConnection: function () {
    var that = this;
    wx.closeBLEConnection({
      deviceId: that.data.deviceId
    })
    that.setData({
      connected: false,

    });
    wx.showToast({
      title: '连接已断开',
      icon: 'success'
    });
    setTimeout(function () {
      wx.navigateBack();
    }, 2000)
  },

  //监听input表单
  inputTextchange: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },


  wifiprovision: function () {
    var that = this;
    wx.navigateTo({
      url: '/pages/wifi/wifi?name=' + '&deviceId=' + encodeURIComponent(that.data.deviceId)
    })

  },


  //向蓝牙设备发送一个0x00的16进制数据
  
  lanya8: function () {
    let that = this
    console.log('开始发送指令------------')
    that.setData({
      receData: ''
    })
    receData = ''
    let hex = that.data.comandInput
    console.log('发送的指令' + hex)
    that.setData({
      sendData: '发送指令:' + hex

    })

    //开始分包

    let dataArray = utils.datasubpck(hex)
    console.log(that.data.deviceId + "分包后的数组" + dataArray)
    console.log(that.data.deviceId)
    console.log(that.data.serviceId)
    console.log(that.data.writeCharacteristicId)
    //deviceWrite(that.data.deviceId, that.data.serviceId, that.data.writeCharacteristicId, dataArray, 0, that)
    utils.deviceWrite(that.data.deviceId, dataArray, 0, that)



  },



  notifyListener: function (rcvdata, res, rcvbytelength) {
    let that = this
    console.log('接收到数据')
    console.dir(rcvdata)
    console.log("jieshoudao:" + res);
    receData = receData + res;
    that.setData({
      jieshoudao: receData
    })






  },


  comandInput: function (e) {
    var that = this
    console.log('指令------' + e.detail.value)
    that.setData({
      comandInput: e.detail.value
    })
  }

})