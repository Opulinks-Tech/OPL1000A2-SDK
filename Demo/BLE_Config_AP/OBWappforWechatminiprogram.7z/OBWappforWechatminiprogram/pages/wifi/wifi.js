// pages/wifi/wifi.js
var app = getApp();
var utils = require("../../utils/util.js");

//消息提示框
function showLoading(msg) {
  wx.showLoading({
    title: msg,
  })
}

function encodeToHex(str) {
  var r = "";
  var e = str.length;
  var c = 0;
  var h;
  while (c < e) {
    h = str.charCodeAt(c++).toString(16);
    while (h.length < 2) h = "0" + h;
    r += h;
  }
  return r;
}

function decimalToHex(d, padding) {
  var hex = Number(d).toString(16);
  padding = typeof (padding) === "undefined" || padding === null ? padding = 2 : padding;

  while (hex.length < padding) {
    hex = "0" + hex;
  }

  return hex;
}


const changeEndianness = (string) => {
  const result = [];
  let len = string.length - 2;
  while (len >= 0) {
    result.push(string.substr(len, 2));
    len -= 2;
  }
  return result.join('');
}



function getAuthModeDescription(authmode) {
  var description = "";

  switch (authmode) {
    case 0:
      description = "OPEN";
      break;
    case 1:
      description = "WEP";
      break;
    case 2:
      description = "WPA";
      break;
    case 3:
      description = "WPA2";
      break;
    case 4:
      description = "WPA/WPA2";
      break;
    case 5:
      description = "WPA2-Enterprise";
      break;
  }

  return description;
}

function wifirst(deviceId, that){
  wx.removeStorage({ key: 'orderInfo', success: function (res) { that.setData({ storageData: [] }) }, })

  console.log('开始发送指令------------')
  let hex = "07000000"//that.data.comandInput
  console.log('发送的指令' + hex)

  //开始分包
  let dataArray = utils.datasubpck(hex)
  console.log(deviceId + "分包后的数组" + dataArray)
  utils.deviceWrite(deviceId, dataArray, 0)


}


//向蓝牙设备发送一个0x00的16进制数据
function scanAP(deviceId, that) {
  showLoading('Scan AP...')
  wx.removeStorage({ key: 'orderInfo', success: function (res) { that.setData({ storageData: [] }) }, })

  console.log('开始发送指令------------')
  let hex = "000002000102"//that.data.comandInput
  console.log('发送的指令' + hex)

  //开始分包
  let dataArray = utils.datasubpck(hex)
  console.log(deviceId + "分包后的数组" + dataArray)
  utils.deviceWrite(deviceId, dataArray, 0)

};

function bin2String(array) {
  var result = "";
  for (var i = 0; i < array.length; i++) {
    result += String.fromCharCode(parseInt(array[i], 2));
  }
  return result;
}

function hex2a(hexx) {
  var hex = hexx.toString().replace(/,/g, "");//force conversion
  var str = '';
  for (var i = 0; i < hex.length; i += 2)
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
  return str;
}

var apconnectstatus=0;
var idx = 0;
var res = "";
var templen = 0;
var rcvdata = [];

var g_i=0;
var rawdatalen=0;
var packetlen=0;

Page({

  /**
   * 页面的初始数据
   */
  data: {

    rcvdata:'',
    wifiInfo:[],
    ssids:{},
    ifName: false,
    apconnectstatus: 0,
    password: '',
    bssid: '',
    connected: false,
    conntossid: '',
    scroll_height: 0,
    deviceId:''

  },

  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let windowHeight = wx.getSystemInfoSync().windowHeight // 屏幕的高度    
    let windowWidth = wx.getSystemInfoSync().windowWidth // 屏幕的宽度    
    this.setData({
      scroll_height: windowHeight * 600 / windowWidth - (0) - 30
    }) 

    let that = this;
    utils.initBle(that)
    let devid = decodeURIComponent(options.deviceId);
    this.setData({
      deviceId: devid,
    });
    wx.getStorage({
      key: 'orderInfo',
      success: function (res) {
        that.setData({
          jieshoudao: res.data
        })
      }
    })

    
    scanAP(devid, that);


    

  },

  wifireset(){
    let that = this;
    wifirst(that.data.deviceId, that);
    that.setData({
      conntossid: '',
      ssids: {}
    })


  },


  
  /**
   * 接收数据 
   */
  
  notifyListener: function (temprcvdata, tempstr, rcvbytelength, orgdata) {
    let that =this
    console.log('接收到数据')
    console.dir(temprcvdata)


    if (g_i==0){
      var hex_rawdatalen = temprcvdata[3] + temprcvdata[2];
      rawdatalen = parseInt(hex_rawdatalen, 16);
      g_i = g_i + 1;
      packetlen = rawdatalen+4;
    }
    
    templen = templen + rcvbytelength;
    if (templen < packetlen){
      res = res+tempstr;

      let buffer = orgdata.value
      let dataView = new DataView(buffer)

      console.log("拿到的数据")
      console.log("dataView.byteLength", dataView.byteLength)
      for (let i = 0; i < dataView.byteLength; i++) {
//        console.log("0x" + dataView.getUint8(i).toString(16))
        rcvdata.push(dataView.getUint8(i).toString(16))
      }
    }else{

      res = res + tempstr;

      let buffer = orgdata.value
      let dataView = new DataView(buffer)

      console.log("拿到的数据")
      console.log("dataView.byteLength", dataView.byteLength)
      for (let i = 0; i < dataView.byteLength; i++) {
        //        console.log("0x" + dataView.getUint8(i).toString(16))
        rcvdata.push(dataView.getUint8(i).toString(16))
      }
    
      templen = 0;
      g_i=0;
      
      
      if (packetlen<4) {

        return

      }else if ((res.search("0110010000")) != -1) {
        res = "";
        rcvdata = [];
        packetlen = 0;

        return

      } else if ((res.substr(0, 5).search("0210")) != -1)
      {

        var isconn = res
        isconn = isconn.substr(isconn.length - 2);
        if (isconn.search("00") != -1){

          showLoading('连接成功');
          setTimeout(function () {
            wx.hideLoading()
          }, 2000);
          this.setData({
            connected: true,

          });
        }else{
          showLoading('连接失敗');
          setTimeout(function () {
            wx.hideLoading()
          }, 2000);
          this.setData({
            connected: false,

          });

        }

        

      } else if ((res.search("0810010000")) != -1){

        console.log("WiFi Reset Successfully!!!");

        wx.showToast({
          title: 'WiFi reset',
          icon: 'success'
        });


        this.setData({
          ssids: {}
        });
        scanAP(that.data.deviceId, that);

      }else if (res.substr(0, 5).search("0110") != -1 || res.substr(0, 5).search("0010") != -1){


        setTimeout(function () {
          wx.hideLoading()
        }, 2000);

        var connected = res;
        
        connected = connected.substr(connected.length - 2);
        if (connected.search("00") != -1)
          apconnectstatus = 0;
        else if (connected.search("01") != -1){
          apconnectstatus = 1;

        }
    

        var ssidLength = 0;
        var ssid = "";
        var t_ssid = [];
        var i = 0;
        var hexString = rcvdata[4];
        ssidLength = parseInt(hexString, 16);
        for (i = 0; i < ssidLength; i++) {
          t_ssid.push(rcvdata[i + 5]);
        }

        ssid = hex2a(t_ssid);

        var bssid = [];
        var h;
        for (i = 0; i < 6; i++){
          h = rcvdata[i + 5 + ssidLength];
          while (h.length < 2) h = "0" + h;
          bssid.push(h);
        }

          

        const authmode = parseInt(rcvdata[11 + ssidLength], 16);

        // rssi
        const rssi = parseInt(rcvdata[12 + ssidLength], 16);

        console.log("SSID: " + ssid)
        console.log("bssid：" + bssid[0] + ":" + bssid[1] + ":" + bssid[2] + ":" + bssid[3] + ":" + bssid[4] + ":" + bssid[5])
        console.log("authmode: " + authmode)
        console.log("rssi：" + rssi)


        var wifiInfo = {
          ssid: ssid,
          bssid: bssid[0] + bssid[1] + bssid[2] + bssid[3] + bssid[4] + bssid[5],
          authmode: authmode,
          rssi: rssi,
          apconnectstatus: apconnectstatus
        }


        that.data[`ssids[${idx}]`] = wifiInfo
        idx = idx + 1;
        that.setData(that.data)


        if (connected.search("01") != -1) {
          this.setData({
            connected: true,
            conntossid: ssid
          });

        }

      }//end if (res.substr(0, 5).search("0110") != -1 || res.substr(0, 5).search("0010") != -1){

      res = "";
      rcvdata = [];
      packetlen = 0;

    }

    
  },


  connectToAp: function (e) {

    var that = this;
    const ssid = e.currentTarget.dataset.ssid
    const bssid = e.currentTarget.dataset.bssid
    const apconnectstatus = e.currentTarget.dataset.apconnectstatus
    const authmode = e.currentTarget.dataset.authmode

    that.setData({
      conntossid: ssid,
      bssid: bssid,
      apconnectstatus: apconnectstatus,
      connected:false
    })

    if (apconnectstatus == 0 && authmode!=0){

      that.setData({
        ifName: true,
        password: ''
      }) 

    } else if ((apconnectstatus == 1 && authmode != 0) || (apconnectstatus == 0 && authmode == 0)){
      showLoading('连接中...')
      var hex_cmdid = "0001"
      var password = that.data.password

      var cmdlen = 8 + password.length

      var hex_cmdlen = ('0000' + cmdlen.toString(16)).slice(-4); //009A
      var hex_apconnectstatus = decimalToHex(apconnectstatus, 2); //00
//      var hex_pass = encodeToHex(password);
      var hex_passlen = decimalToHex(0, 2);
      var hex_bssid = that.data.bssid;

      var cmd = changeEndianness(hex_cmdid) + changeEndianness(hex_cmdlen) + hex_bssid + hex_apconnectstatus + hex_passlen


      //开始分包
      let dataArray = utils.datasubpck(cmd)
      console.log(that.data.deviceId + "分包后的数组" + dataArray)
      utils.deviceWrite(that.data.deviceId, dataArray, 0)

    }


  },

  


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that =this
  //  if (Object.keys(ssids).length != 0) {

      this.setData({
        ssids: {},
      });
  //  }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  InputPassword: function (e) {

    var password = e.detail.value
    

    this.setData({
      password: password
    })
  },



  //取消按钮  
  cancel: function (e) {
    this.setData({
      ifName: false
    });
  },
  //确认  
  confirm: function (e) {

    showLoading('连接中...')


    
    this.setData({
      ifName: false
    })
    console.log("password: " + this.data.password)

    var hex_cmdid = "0001"
    var password = this.data.password

    var cmdlen = 8 + password.length

    var hex_cmdlen = ('0000' + cmdlen.toString(16)).slice(-4); //009A
    var hex_apconnectstatus = decimalToHex(this.data.apconnectstatus,2); //00
    var hex_pass = encodeToHex(password);
    var hex_passlen = decimalToHex(password.length, 2);
    var hex_bssid = this.data.bssid;

    var cmd = changeEndianness(hex_cmdid) + changeEndianness(hex_cmdlen) + hex_bssid + hex_apconnectstatus + hex_passlen + hex_pass


    //开始分包
    let dataArray = utils.datasubpck(cmd)
    console.log(this.data.deviceId + "分包后的数组" + dataArray)
    utils.deviceWrite(this.data.deviceId, dataArray, 0)





  }  





})